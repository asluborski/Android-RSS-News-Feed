package edmt.dev.androidrssfeed.Interface;

import android.view.View;

/**
 * Created by reale on 5/5/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position,boolean isLongClick);
}
